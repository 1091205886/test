//
// Created by msi on 2020/7/16.
//

#include "utils.h"

class NumberConversionError : public std::exception {
public:
    std::string message;
    NumberConversionError(std::string msg)
            : message(msg)
    {};

    virtual ~NumberConversionError()
    {};

    std::string what(){
        return message;
    }
};

double string2Double(std::string s){
    char* p;
    //strtod函数返回转换后的双精度浮点数，如果没有执行有效的转换，则返回零（0.0）
    double d = ::strtold(s.c_str(), &p);
    if (*p != 0){
        std::stringstream ss;
        ss << "NumberConversionError: parseDouble() error in argument \"" << s << "\", '"
           << *p << "' is not a number.";
        throw NumberConversionError(ss.str());
    }
    return d;
}

void log_State_nominal(StateNominal input) {
    std::cout<<std::setprecision(20);
    std::cout<<"State_nominal Log:"<<std::endl;
    std::cout<<"position: "<<input.p.transpose()<<std::endl;
    std::cout<<"volicity: "<<input.v.transpose()<<std::endl;
    std::cout<<"Quaterniond: \n"<<input.q.toRotationMatrix()<<std::endl;
    std::cout<<"Acc_bias: "<<input.acc_bias.transpose()<<std::endl;
    std::cout<<"Gyro_bias: "<<input.gyro_bias.transpose()<<std::endl;
    std::cout<<"g: "<<input.g.transpose()<<std::endl;
    std::cout<<"R_i_l: \n"<<input.q_i_l.toRotationMatrix()<<std::endl;
    std::cout<<"t_i_l: "<<input.t_i_l.transpose()<<std::endl;
}

Eigen::Quaterniond theta2q(const Eigen::Vector3d theta) {
    Eigen::Vector3d dtheta_half = theta / 2.0;
    Eigen::Quaterniond dq;
    dq.w() = 1;
    dq.x() = dtheta_half.x();
    dq.y() = dtheta_half.y();
    dq.z() = dtheta_half.z();
    dq.normalize();
    return dq;
}
Eigen::Quaterniond theta2q(Eigen::Vector3d gyro, double delta_t) {
    // 方法一
//    Eigen::Matrix3d a=Sophus::SO3d::hat(gyro*delta_t);
//    return Eigen::Quaterniond(Sophus::SO3d::exp(gyro*delta_t).matrix());

    //方法二
    Eigen::Vector3d dtheta_half = gyro * delta_t / 2.0;
    Eigen::Quaterniond dq;
    dq.w() = 1;
    dq.x() = dtheta_half.x();
    dq.y() = dtheta_half.y();
    dq.z() = dtheta_half.z();
    dq.normalize();
    return dq;
}

Eigen::Matrix3d q2RotMat(Eigen::Quaterniond q) {
    return q.matrix();
}

void readIMUData(const std::string &acc,const std::string &gyro,const std::string &time,std::deque<ImuMsg,Eigen::aligned_allocator<ImuMsg>>& imu_msg_deq)
{
    std::ifstream f_acc,f_gyro,f_time;
    f_acc.open(acc.c_str());
    f_gyro.open(gyro.c_str());
    f_time.open(time.c_str());

    if (!f_acc.is_open() && !f_gyro.is_open() && !f_time.is_open()) {
        std::cout << " can't open LoadFeatures file " << std::endl;
        return;
    }

    bool readHeader = false;
    while (!f_acc.eof() && !f_gyro.eof() && !f_time.eof()) {
        /// 读取加速度
        std::string s_acc;
        std::getline(f_acc, s_acc);
        /// 角速度
        std::string s_gyro;
        std::getline(f_gyro, s_gyro);
        /// 时间戳
        std::string s_time;
        std::getline(f_time, s_time);

        if (!readHeader) {
            readHeader = true;
            continue;
        }

        ImuMsg msg;

        if(!s_time.empty()){
            std::stringstream ss(s_time);
            double time=0;
            std::string item;
            std::getline(ss, item);
            time = string2Double(item);
            //std::cout<<std::setprecision(12);
            //std::cout<<time<<std::endl;
            msg.timestamp=time;
        }

        if (!s_acc.empty()) {
            std::stringstream ss(s_acc);

            Eigen::Vector3d acc = Eigen::Vector3d::Zero();
            for (int i = 0; i < 3; i++) {
                std::string item;
                std::getline(ss, item, ',');
                acc(i) = string2Double(item);
            }
            //            double tmp=acc.x();
            //            acc.x()=acc.y();
            //            acc.y()=tmp;
            //            acc.z()=-acc.z();
            msg.acc_m=acc;
        }

        if (!s_gyro.empty()) {
            std::stringstream ss(s_gyro);
            Eigen::Vector3d gyro = Eigen::Vector3d::Zero();
            for (int i = 0; i < 3; i++) {
                std::string item;
                std::getline(ss, item, ',');
                gyro(i) = string2Double(item);
            }
            //            double tmp=gyro.x();
            //            gyro.x()=gyro.y();
            //            gyro.y()=tmp;
            //            gyro.z()=-gyro.z();
            msg.gyro_m=gyro*M_PI/180;
        }
        if(!s_gyro.empty() && !s_time.empty() && !s_acc.empty()){
            //msg.Log();
            imu_msg_deq.emplace_back(msg);
        }
    }
    std::cout<<"测量数据读取完成: "<<"共 ["<<imu_msg_deq.size()<<"]帧数据"<<std::endl;
}

void readGTData(const std::string &pos, const std::string &atti, const std::string& velocity, const std::string &time, std::deque<StateNominal,Eigen::aligned_allocator<StateNominal>> &gt_deque)
{
    gt_deque.clear();
    std::ifstream f_pos,f_atti,f_vel,f_time;
    f_pos.open(pos.c_str());
    f_atti.open(atti.c_str());
    f_vel.open(velocity.c_str());
    f_time.open(time.c_str());;

    if (!f_pos.is_open() && !f_atti.is_open() && !f_time.is_open()) {
        std::cout << " Can't open file " << std::endl;
        return;
    }

    int count=0;
    bool readHeader = false;
    while (!f_pos.eof() && !f_atti.eof() && !f_vel.eof() && !f_time.eof()) {
        /// 位置真值
        std::string s_pos;
        std::getline(f_pos, s_pos);
        /// 姿态真值
        std::string s_atti;
        std::getline(f_atti,s_atti);
        /// 速度真值
        std::string s_vel;
        std::getline(f_vel,s_vel);
        /// 时间戳
        std::string s_time;
        std::getline(f_time, s_time);

        if (!readHeader) {
            readHeader = true;
            continue;
        }

        StateNominal msg;

        if(!s_time.empty()){
            std::stringstream ss(s_time);
            double time=0;
            std::string item;
            std::getline(ss, item);
            time = string2Double(item);
            msg.timestamp=time;
        }

        if (!s_pos.empty()) {
            std::stringstream ss(s_pos);

            Eigen::Vector3d pos = Eigen::Vector3d::Zero();
            for (int i = 0; i < 3; i++) {
                std::string item;
                std::getline(ss, item, ',');
                pos(i) = string2Double(item);
            }
//            std::cout<<pos.transpose()<<std::endl;
//            for (int i = 0; i < 3; i++) {
//                std::string item;
//                std::getline(ss, item, ',');
//            }
            //            double tmp=acc.x();
            //            acc.x()=acc.y();
            //            acc.y()=tmp;
            //            acc.z()=-acc.z();
            msg.p=pos;
        }

        if (!s_atti.empty()) {
            std::stringstream ss(s_atti);

            Eigen::Vector4d q_v=Eigen::Vector4d::Identity();
            for (int i = 0; i < 4; i++) {
                std::string item;
                std::getline(ss, item, ',');
                q_v[i] = string2Double(item);
            }
            Eigen::Quaterniond q(q_v[0],q_v[1],q_v[2],q_v[3]);
            q.normalize();
            if(q.w()<0){
                q.w()=-q.w();
                q.x()=-q.x();
                q.z()=-q.z();
                q.y()=-q.y();
            }
            //            double tmp=gyro.x();
            //            gyro.x()=gyro.y();
            //            gyro.y()=tmp;
            //            gyro.z()=-gyro.z();
            msg.q=q;
        }

        if(!s_vel.empty()){
            std::stringstream ss(s_vel);

            Eigen::Vector3d vel = Eigen::Vector3d::Zero();
            for (int i = 0; i < 3; i++) {
                std::string item;
                std::getline(ss, item, ',');
                vel(i) = string2Double(item);
            }
            msg.v = vel;
        }

        if( !s_time.empty() && !s_pos.empty() && !s_atti.empty()){
            gt_deque.emplace_back(msg);
        }
    }
    std::cout<<"参考数据读取完成: "<<"共 ["<<gt_deque.size()<<"]帧数据"<<std::endl;
}



void LoadData(std::string filename, std::deque<ImuMsg,Eigen::aligned_allocator<ImuMsg>> &imu_data) {
    std::ifstream f;
    f.open(filename.c_str());

    if (!f.is_open()) {
        std::cerr << " can't open LoadFeatures file " << std::endl;
        return;
    }

    while (!f.eof()) {

        std::string s;
        std::getline(f, s);

        if (!s.empty()) {
            std::stringstream ss;
            ss << s;

            ImuMsg msg;
            double time;
            Eigen::Quaterniond q;
            Eigen::Vector3d t;
            Eigen::Vector3d gyro;
            Eigen::Vector3d acc;

            ss >> time;
            ss >> gyro(0);
            ss >> gyro(1);
            ss >> gyro(2);
            ss >> acc(0);
            ss >> acc(1);
            ss >> acc(2);


            msg.timestamp = time;         //时间戳
            msg.gyro_m = gyro;            //角速度
            msg.acc_m = acc;              //加速度

            imu_data.emplace_back(msg);

            /*pose.push_back(data);*/
        }
    }
}

void LoadData(std::string filename, std::deque<StateNominal,Eigen::aligned_allocator<StateNominal>> &pose) {
    std::ifstream f;
    f.open(filename.c_str());

    if (!f.is_open()) {
        std::cerr << " can't open LoadFeatures file " << std::endl;
        return;
    }

    while (!f.eof()) {

        std::string s;
        std::getline(f, s);

        if (!s.empty()) {
            std::stringstream ss;
            ss << s;

            StateNominal data;
            double time;
            Eigen::Quaterniond q;
            Eigen::Vector3d t;
            Eigen::Vector3d v;
            Eigen::Vector3d gyro;
            Eigen::Vector3d acc;

            ss >> time;
            ss >> t(0);
            ss >> t(1);
            ss >> t(2);
            ss >> q.w();
            ss >> q.x();
            ss >> q.y();
            ss >> q.z();
            ss >> v(0);
            ss >> v(1);
            ss >> v(2);

            data.timestamp = time;         //时间戳
            data.p = t;
//            if(q.w()<0){
//                q.w()*=-1;
//                q.x()*=-1;
//                q.y()*=-1;
//                q.z()*=-1;
//            }
            data.q = q.normalized();
            data.v= v;
            pose.emplace_back(data);
        }
    }
}


void SaveData(std::string outputFile, std::deque<StateNominal,Eigen::aligned_allocator<StateNominal>> pose) {
    std::fstream f;
    f.open(outputFile.c_str(),std::ios::out|std::ios::trunc);

    if (!f.is_open()) {
        std::cerr << " Can't open Output file " << std::endl;
        return;
    }
    for(auto data : pose){
        f<< std::setiosflags(std::ios::fixed) << data.timestamp<<" ";
        f<< data.p.x()<<" "<<
            data.p.y()<<" "<<
            data.p.z()<<" ";
        Eigen::Quaterniond q(data.q);
        f<< q.x() <<" "<<
            q.y() <<" "<<
            q.z() <<" "<<
            q.w();
        f<< std::endl;
    }
    f.close();
    return;
}

void SaveState(std::string outputFile, std::deque<StateNominal,Eigen::aligned_allocator<StateNominal>> poses)
{
    std::fstream f;
    f.open(outputFile.c_str(),std::ios::out|std::ios::trunc);

    if (!f.is_open()) {
        std::cerr << " Can't open Output file " << std::endl;
        return;
    }
    for(const auto& pose : poses){
        Eigen::Quaterniond qtemp = pose.q;
        // if (qtemp.w() < 0)
        // {
        //     qtemp.coeffs() = -1.0 * qtemp.coeffs();
        // }
        double angle = std::acos(qtemp.w()) * 2;
        double sin_angle = std::sin(angle / 2);
        Eigen::Vector3d dir(0, 0, 0);
        if (sin_angle != 0)
        {
            dir(0) = qtemp.x() / sin_angle;
            dir(1) = qtemp.y() / sin_angle;
            dir(2) = qtemp.z() / sin_angle;
            dir = dir * angle;
        }
        f.precision(12);
        f << pose.timestamp
          << "," << pose.p(0)
          << "," << pose.p(1)
          << "," << pose.p(2)
          << "," << pose.v(0)
          << "," << pose.v(1)
          << "," << pose.v(2)
          // << "," << pose.state.q.x()
          // << "," << pose.state.q.y()
          // << "," << pose.state.q.z()
          // << "," << pose.state.q.w()
          << "," << dir(0)
          << "," << dir(1)
          << "," << dir(2)
          << "," << pose.gyro_bias(0)
          << "," << pose.gyro_bias(1)
          << "," << pose.gyro_bias(2)
          << "," << pose.acc_bias(0)
          << "," << pose.acc_bias(1)
          << "," << pose.acc_bias(2)
          << "," << pose.t_i_l(0)
          << "," << pose.t_i_l(1)
          << "," << pose.t_i_l(2)
          << std::endl;
    }
    f.close();
}

//State_nominal MotionData2State(MotionData input) {
//    State_nominal state;
//    state.p=input.twb;
//    state.v=input.imu_velocity;
//    state.q=input.q;
//    state.acc_bias=input.imu_acc_bias;
//    state.gyro_bias=input.imu_gyro_bias;
//    state.timestamp=input.timestamp;
////    state.g<<0,0,-9.79484197226503638944;
//    return state;
//}

void log_Matrix(std::string str,Eigen::MatrixXd mat) {
    std::cout<<str<<std::endl<<mat<<std::endl;
}

Eigen::Matrix3d skew_matrix(Eigen::Vector3d v) {
    Eigen::Matrix3d skew;
    skew<<  0 , -v.z(), v.y(),
            v.z(), 0 , -v.x(),
            -v.y(), v.x() , 0;
    //std::cout<<skew<<std::endl;
    return skew;
}

//MotionData State2MotionData(State_nominal input) {
////    State_nominal state;
////    state.p=input.twb;
////    state.v=input.imu_velocity;
////    state.q=Eigen::Quaterniond(input.Rwb);
////    state.acc_bias=input.imu_acc_bias;
////    state.gyro_bias=input.imu_gyro_bias;
////    state.g<<(0,0,-9.81);
//
//    MotionData data;
//    data.twb=input.p;
//    data.imu_velocity=input.v;
//    data.q=input.q.matrix();
//    data.Rwb=input.q.matrix();
//    data.imu_acc_bias=input.acc_bias;
//    data.imu_gyro_bias=input.gyro_bias;
//    data.timestamp=input.timestamp;
//    return data;
//}

void normalizeQ(Eigen::Quaterniond &q) {
    if(q.w()<0){
        q.w()=-q.w();
        q.x()=-q.x();
        q.y()=-q.y();
        q.z()=-q.z();
    }
    q.normalize();
}
void SaveImuData(std::string outputFile, const std::deque<ImuMsg, Eigen::aligned_allocator<ImuMsg>> &imu_msg)
{
    std::fstream f;
    f.open(outputFile.c_str(),std::ios::out|std::ios::trunc);

    if (!f.is_open()) {
        std::cerr << " Can't open Output file " << std::endl;
        return;
    }
    for(auto data : imu_msg){
        f << std::setiosflags(std::ios::fixed) << data.timestamp<<" ";
        f << data.acc_m.x() << " "
          << data.acc_m.y() << " "
          << data.acc_m.z() << " "
          << data.gyro_m.x() << " "
          << data.gyro_m.y() << " "
          << data.gyro_m.z() << " ";

          f<< std::endl;
    }
    f.close();
}
