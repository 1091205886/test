//
// Created by msi on 2020/7/16.
//

#include "ESKF.h"

void ESKF::init_state_nominal(const StateNominal &input) {
    this->curr_state=input;
//    this->curr_state.gyro_bias = Eigen::Vector3d(1, 1, 1)*1e-2;
//    this->curr_state.acc_bias = Eigen::Vector3d (1, 1, 1)*1e-2;
    this->curr_state.g=gravity;
//    curr_state.q = curr_state.q * Eigen::Quaterniond(0.9879654, 0.0940609, 0.0789265, 0.0940609);
    normalizeQ(curr_state.q);
//    curr_state.t_i_l = Eigen::Vector3d (0.3313025958582832553, -0.088694193388869857486,   0.61128812108691144012)*1e0;
    this->timestamp=input.timestamp;
}

void ESKF::update_imu_msg(const ImuMsg &curr_m) {
    curr_imu=curr_m;
}

//void ESKF::init_observability_anlysis() {
//    Eigen::Matrix3d F23=skew_matrix(this->curr_state.q*this->curr_imu.acc_m);
//    Ft.block<3,3>(0,3)=Eigen::Matrix3d::Identity();
//    Ft.block<3,3>(3,6)=F23;
//    Ft.block<3,3>(3,12)=this->curr_state.q.matrix();
//    Ft.block<3,3>(6,9)=-this->curr_state.q.matrix();
//}

//void ESKF::update_observability_anlysis(const StateNominal & measure,int index) {
//
//    if(index==0){
//        std::cout<<"index=0"<<std::endl;
//        Ot.block(3*index, 0, 3, 15)=Gt;
//    }else if(index>0){
//        Ot.block(3*index, 0, 3, 15) = Ot.block(3*(index-1), 0, 3, 15) * Ft;
//    }
//
//    Yt.block(3*index,0,3,1)=measure.p-curr_state.p;
//}

//void ESKF::solve_observability_anlysis(bool reset) {
//    static bool first=true;
//    if(reset)
//        first=true;
//    // 更新Oso
//    if(first){
//        Oso.setZero();
//        Y.setZero();
//        Oso=Ot;
//        Y=Yt;
//        first=false;
//    }else{
//        Oso.conservativeResize(Oso.rows()+Ot.rows(),Oso.cols());
//        Oso.block(Oso.rows()-Ot.rows(),0,Ot.rows(),Ot.cols())=Ot;
//        Y.conservativeResize(Y.rows()+Yt.rows(),Y.cols());
//        Y.block(Y.rows()-Yt.rows(),0,Yt.rows(),Yt.cols())=Yt;
//    }
//
//    // 分解Oso
//    Eigen::JacobiSVD<Eigen::MatrixXd> svd(Oso, Eigen::ComputeThinU | Eigen::ComputeThinV);
//    Eigen::MatrixXd U = svd.matrixU();
//    Eigen::MatrixXd V = svd.matrixV();
//    Eigen::MatrixXd singular_value = svd.singularValues();
//
//    std::cout<<"===============Qso能观矩阵奇异值=================="<<std::endl;
//    std::cout<<"TIME: "<<this->timestamp<<std::endl;
//
//    std::cout<<"U "<<U.rows()<<" "<<U.cols()<<std::endl;
//    std::cout<<"V "<<V.rows()<<" "<<V.cols()<<std::endl;
//    std::cout<< "Single Value" << std::endl << singular_value/singular_value(0)<< std::endl;
//
//    Eigen::VectorXd X = (V * singular_value.asDiagonal().inverse() * U.transpose()) * Y;
//
//    // 下面求出 X 的具体组合形式
//    std::cout<<"===============奇异值变量关系===================="<<std::endl;
//    for(int i = 0; i < 15; i++) {
//        Eigen::Matrix<double, 15, 1> Xi;
//        Xi = V.col(i) * U.transpose().row(i)  / singular_value(i) * Y;
//        Eigen::MatrixXd::Index maxIndex;
//        Xi.maxCoeff(&maxIndex);
//
//        std::vector<std::string> stateName= {"dP_E", "dP_N", "dP_U",
//                                             "dV_E", "dV_N", "dV_U",
//                                             "dPhi_E", "dPhi_N", "dPhi_U",
//                                             "Gyro_bx", "Gyro_by", "Gyro_bz",
//                                             "Acc_bx", "Acc_by", "Acc_bz"};
//
//        std::cout << "第" << i+1 << "个奇异值对应的变量: " << stateName[maxIndex] << std::endl;
//    }
//}



void ESKF::log_state_nominal() {
    log_State_nominal(this->curr_state);
}

bool ESKF::predict(const ImuMsg &imu_msg_) {
    if(imu_msg_.timestamp== this->timestamp)
        return false;

    _predict_err_covar(imu_msg_);
    _predict_nominal_state(imu_msg_);
    this->timestamp=imu_msg_.timestamp;
    return true;
}

void ESKF::_predict_err_covar(const ImuMsg &imu_msg_) {

    V3d w_m=imu_msg_.gyro_m;
    V3d a_m=imu_msg_.acc_m;
    V3d a_b=curr_state.acc_bias;
    V3d w_b=curr_state.gyro_bias;
    Eigen::Quaterniond q = curr_state.q;
    M3d R = q.matrix();

    // 状态转移矩阵
    Eigen::MatrixXd F=Eigen::MatrixXd::Identity(err_state.Vec.size(),err_state.Vec.size());
    // 连续时间下的系统矩阵 Ft
    Ft.block<3,3>(0,3)=M3d::Identity();
    Ft.block<3,3>(3,6)=-R*skew_matrix(a_m-a_b);
    Ft.block<3,3>(3,9)=-R;
//    Ft.block<3,3>(3,15)=M3d::Identity();
    Ft.block<3,3>(6,6)=-skew_matrix(w_m-w_b);
    Ft.block<3,3>(6,12)= -M3d::Identity();

    // 耗时主要在这里
//    TicToc tic;
    double dt=imu_msg_.timestamp-this->timestamp;
    delta_t = dt;
    Eigen::MatrixXd Fdt = Ft * dt;
    Eigen::MatrixXd Fdt2= Fdt * Fdt;
    Eigen::MatrixXd Fdt3= Fdt2 * Fdt;

    // 使用3阶截断近似得到状态转移矩阵 (292)
    F= F + Fdt + 0.5*Fdt2 +(1.0/6.0)*Fdt3;
//    F.block<3,3>(0,3)=M3d::Identity() * dt;
//    F.block<3,3>(3,6)=-R * skew_matrix(a_m - a_b) * dt;
//    F.block<3,3>(3,9)= -R * dt;
//    F.block<3,3>(3,15) = M3d::Identity() * dt;
//    F.block<3,3>(6,6) = theta2q((w_m-w_b)*dt).conjugate().toRotationMatrix();
//    F.block<3,3>(6,12) = -M3d::Identity() * dt;

    // (3, 0): 速度--acc_noise
    // (6, 3): 姿态--gyro_noise
    // (9, 6): acc_bias -- acc_bias_noise
    // (12, 9): gyro_bias -- gyro_bias_noise
    Fi = Eigen::MatrixXd::Zero(err_state.Vec.size(), 12);
    Fi.block<3,3>(3, 0)=Ft.block<3,3>(3,9);         // acc_noise是与 acc_bias同一个通道引入误差到速度的
    Fi.block<3,3>(6, 3)=Ft.block<3,3>(6,12);        // gyro_noise是与 gyro_bias同一个通道引入误差到姿态的
    Fi.block<3,3>(9, 6)=Eigen::Matrix3d::Identity();
    Fi.block<3,3>(12, 9)=Eigen::Matrix3d::Identity();
    Eigen::MatrixXd Qxx=Fi * Qi * Fi.transpose();
    // 离散化
    Qxx.block<3,3>(3, 0) /= dt;
    Qxx.block<3,3>(6, 3) /= dt;
    Qxx.block<3,3>(9, 6) *= dt;
    Qxx.block<3,3>(12, 9) *= dt;

    // 更新协方差
    this->P = F * this->P.eval() * F.transpose() + Qxx * dt;
}

void ESKF::_predict_nominal_state(const ImuMsg &imu_msg_) {
//    V3d p = curr_state.p;
//    Eigen::Quaterniond q = curr_state.q;
//    V3d v = curr_state.v;
//    V3d a_b = curr_state.acc_bias;
//    V3d w_b = curr_state.gyro_bias;
//    V3d g = curr_state.g;
//
//    V3d w_m = imu_msg_.gyro_m;
//    V3d a_m = imu_msg_.acc_m;
//    double dt = imu_msg_.timestamp- this->timestamp;
//
//    // 转换成轴角 （实际上没必要）
//    // 实际上: angle*w_ = w_m-w_b
//    //double angle = (w_m-w_b).norm();
//    //V3d w_ = (w_m-w_b)/angle;
//    //M3d dq_half_R = Sophus::SO3d::exp(0.5*dt*angle*w_).matrix();
//    //Eigen::Quaterniond dq_half= Eigen::Quaterniond(dq_half_R);
//    //M3d dq_R = Sophus::SO3d::exp(dt*angle*w_).matrix();
//    //Eigen::Quaterniond dq= Eigen::Quaterniond(dq_R);
//
//    //使用近似:  (把下面的"w_m-w_b"替换成"angle*w_"也是一样的)
//    Eigen::Quaterniond dq_half = theta2q(w_m-w_b,0.5*dt);
//    Eigen::Quaterniond dq= theta2q(w_m-w_b,dt);
//    Eigen::Quaterniond q_half_next=q*dq_half;
//    Eigen::Quaterniond q_next=q*dq;
//    normalizeQ(q_half_next);
//    normalizeQ(q_next);
//
//    // RK4更新位置和速度
//    M3d R = q.matrix();
//    M3d R_half_next= q_half_next.matrix();
//    M3d R_next = curr_state.q.matrix();
//
//    V3d v_k1 = R * (a_m-a_b) - g;
//    V3d v_k2 = R_half_next * (a_m-a_b) - g;
//    V3d v_k3 = v_k2;
//    V3d v_k4 = R_next * (a_m-a_b) - g;
//    V3d v_next = v+ dt * (v_k1 + 2 * v_k2 + 2 * v_k3 + v_k4) / 6;
//
//    // 位置
//    V3d p_k1 = v;
//    V3d p_k2 = v+0.5*dt*v_k1;
//    V3d p_k3 = v+0.5*dt*v_k2;
//    V3d p_k4 = v+dt*v_k3;
//    V3d p_next = p + dt * (p_k1 + 2 * p_k2 + 2 * p_k3 + p_k4) / 6;
//
//    curr_state.p=p_next;
//    curr_state.v=v_next;
//    curr_state.q=q_next;
//    curr_state.timestamp=imu_msg_.timestamp;

//////////////////////////////////////////////////////////////////////

//    double  deltaT=imu_msg_.timestamp-this->timestamp;
//    static ImuMsg last_imu_msg;
//    Eigen::Vector3d equalRotVec_last=last_imu_msg.gyro_m*deltaT;
//    Eigen::Vector3d equalRotVec=imu_msg_.gyro_m*deltaT;
//    Eigen::Vector3d acc_b_last=last_imu_msg.acc_m;
//    Eigen::Vector3d acc_b_curr=imu_msg_.acc_m;
//
//    Eigen::Vector3d wenn;
//    wenn[0]=-curr_state.v[0]/(Rm+curr_state.p[2]);
//    wenn[1]=curr_state.v[1]/(Rn+curr_state.p[2]);
//    wenn[2]=curr_state.v[1]*tan(latitude)/(Rn+curr_state.p[2]);
//    Eigen::Vector3d wien;
//    wien[0]=0;
//    wien[1]=wie*cos(latitude);
//    wien[2]=wie*sin(latitude);
//
//    ///姿态更新
//    Eigen::Quaterniond last_q=curr_state.q;
//    curr_state.q=/*theta2q((wien+wenn),deltaT).inverse()**/curr_state.q*theta2q(equalRotVec+(double)1/12.0*equalRotVec_last.cross(equalRotVec));
//    curr_state.q.normalize();
//    Eigen::Vector3d acc_n=last_q*acc_b_curr -curr_state.g;
//    ///速度更新
//    Eigen::Vector3d last_v=curr_state.v;
//    curr_state.v=curr_state.v+acc_n*deltaT;
////                -(2*wien+wenn).cross(curr_state.v)*deltaT;
//    ///位置更新
//    curr_state.p=curr_state.p+0.5*(last_v+curr_state.v)*deltaT;
//    ///时间戳更新
//    curr_state.timestamp=imu_msg_.timestamp;
//
//    ///保存上一帧数据
//    last_imu_msg=imu_msg_;

//////////////////////////////////////////////////////////////

    static ImuMsg last_imu_msg = imu_msg_;

    V3d p = curr_state.p;
    Eigen::Quaterniond q = curr_state.q;
    V3d v = curr_state.v;
    V3d a_b = curr_state.acc_bias;
    V3d w_b = curr_state.gyro_bias;
    V3d g = curr_state.g;

    V3d w_m = imu_msg_.gyro_m;
    V3d a_m = imu_msg_.acc_m;
    double dt = imu_msg_.timestamp- this->timestamp;

    Eigen::Vector3d wenn;
    wenn[0]=-curr_state.v[0]/(Rm+curr_state.p[2]);
    wenn[1]=curr_state.v[1]/(Rn+curr_state.p[2]);
    wenn[2]=curr_state.v[1]*std::tan(latitude * M_PI / 180)/(Rn+curr_state.p[2]);
    Eigen::Vector3d wien;
    wien[0]=0;
    wien[1]=wie*std::cos(latitude * M_PI / 180);
    wien[2]=wie*std::sin(latitude * M_PI / 180);

    //使用近似:  (把下面的"w_m-w_b"替换成"angle*w_"也是一样的)
    Eigen::Vector3d w_1 = last_imu_msg.gyro_m - w_b;
    Eigen::Vector3d w_2 = w_m - w_b;
    Eigen::Vector3d equalRotVec_last=w_1*dt;
    Eigen::Vector3d equalRotVec = w_2*dt;
    Eigen::Quaterniond dq= theta2q(equalRotVec + (double)1/12.0*equalRotVec_last.cross(equalRotVec)); //theta2q(0.5*(w_1 + w_2),dt);
    Eigen::Quaterniond q_next=q*dq;
    normalizeQ(q_next);

    Eigen::Vector3d f1 = last_imu_msg.acc_m - a_b;
    Eigen::Vector3d f2 = a_m - a_b;
    Eigen::Vector3d v_next = v + dt * (0.5 * (q * f1 + q_next * f2) + g);
    Eigen::Vector3d p_next = p + 0.5 * dt * (v + v_next);
    curr_state.p=p_next;
    curr_state.v=v_next;
    curr_state.q=q_next;
    curr_state.timestamp=imu_msg_.timestamp;

//    // RK4更新位置和速度
//    M3d R = q.matrix();
//
//    V3d v_k1 = R * (a_m-a_b) - g;
//    V3d v_next = v+ dt * v_k1 ;
//
//    // 位置
//    V3d p_k1 = v;
//    V3d p_next = p + dt * p_k1 + 0.5*v_k1*dt*dt ;

//    curr_state.p=p_next;
//    curr_state.v=v_next;
//    curr_state.q=q_next;
//    curr_state.timestamp=imu_msg_.timestamp;

    ///保存上一帧数据
    last_imu_msg=imu_msg_;
}

void ESKF::update(const StateNominal &measure, const MeasurementNoise &noise) {

//    // 假设观测mea是雷达在地图上的位姿
//    //
//    auto res = measure.p - (curr_state.q * curr_state.t_i_l + curr_state.p);

    // 观测矩阵H
    // 观测值对 误差状态量的求导
    Eigen::MatrixXd H = Eigen::MatrixXd::Zero(3,err_state.Vec.size());      // 6x18

    // 链式法则： 先对真值求导
    // 与式175有出入，是因为，我们的误差状态量中的姿态误差使用了轴角形式(3维),并且事先把观测值的姿态转换成轴角形式了
    H.block<3,3>(0,0)=M3d::Identity();          // 观测的位置 对 posi_t(真值) 求导
//    H.block<3,3>(3,6)=M3d::Identity();          // 观测的姿态 对 xita_t(真值) 求导
    H.block<3,3>(0,6)=-curr_state.q.toRotationMatrix()* skew_matrix(curr_state.t_i_l);          // 观测的位置 对 posi_t(真值) 求导
    H.block<3,3>(0,18)=curr_state.q.toRotationMatrix();          // 观测的位置 对 posi_t(真值) 求导

    Eigen::MatrixXd P_HT_= this->P * H.transpose();             // 18x6

    // 噪声构成矩阵
    Eigen::MatrixXd V = Eigen::MatrixXd::Identity(3,3);
    V.block<3,3>(0,0)*=pow(noise.p_noise_sigma,2);
//    V.block<3,3>(3,3)*=pow(noise.q_noise_sigma,2);

    // 计算卡尔曼增益
    Eigen::MatrixXd K=P_HT_ * ((H * P_HT_ + V).inverse());                  // 18x6

//    this->P = (Eigen::MatrixXd::Identity(err_state.Vec.size(),err_state.Vec.size()) - K*H)* this->P *
//                  (Eigen::MatrixXd::Identity(err_state.Vec.size(),err_state.Vec.size()) - K*H).transpose() + K * V * K.transpose();
    // 更新误差状态协方差矩阵P
    this->P = (Eigen::MatrixXd::Identity(err_state.Vec.size(),err_state.Vec.size()) - K*H)* this->P.eval();
    // 对称化
    this->P = 0.5*(this->P+ this->P.transpose());

    Eigen::VectorXd delta=Eigen::VectorXd::Zero(3);
//    delta.segment(0,3)=measure.p-curr_state.p;    // 位置误差
    delta.segment(0,3)= measure.p - (curr_state.q * curr_state.t_i_l + curr_state.p);    // 位置误差

    Yt.block<3,1>(0,0) = delta;
    Gt = H;

//    Eigen::Quaterniond q_m =  measure.q;
//    normalizeQ(q_m);
//    Eigen::Quaterniond q = curr_state.q;                    // norminal_state
//    Eigen::Quaterniond q_delta = q.conjugate()*q_m;         // q_m 到 q的变换
////    Eigen::AngleAxisd angleAxis_delta(q_delta);
//    normalizeQ(q_delta);
//    double sin_theta =sqrt(q_delta.x()*q_delta.x()+
//                           q_delta.y()*q_delta.y()+
//                           q_delta.z()*q_delta.z()) ;
//    double angle = asin(sin_theta);
//    V3d axis;
//    if(angle<1e-9){
//        axis.setZero();
//    }else{
//        axis = V3d(q_delta.x(),q_delta.y(),q_delta.z())/sin_theta;
//    }
//    // 角度差
//    delta.segment(3,3)=angle*axis;
//    std::cout<<angle*axis<<std::endl;

    // 根据卡尔曼增益，计算误差
    Eigen::VectorXd errors = K*delta;

//    std::cout<<"delta:=======\n"<<delta.transpose() << std::endl;
//    std::cout<<"errors:======\n"<< errors << std::endl;
//
    //误差状态注入到 nominal_state
    curr_state.p += errors.segment(0,3);
    //更新速度
    curr_state.v += errors.segment(3,3);

    // 四元数姿态更新
    // 方法一:
    //M3d RR = Sophus::SO3d::exp(errors.segment(3,3)).matrix();
    //curr_state.q = curr_state.q * Eigen::Quaterniond(RR);
    // 方法二: 使用近似
    curr_state.q = curr_state.q * Eigen::Quaterniond(
            theta2q(errors.segment(6,3)));

//    Eigen::Vector3d dphi_dir = errors.segment(6,3);
//    double dphi_norm = dphi_dir.norm();
//    if (dphi_norm != 0)
//    {
//        dphi_dir = dphi_dir / dphi_norm;
//        dphi_dir = dphi_dir * std::sin(dphi_norm / 2);
//    }
//    Eigen::Quaterniond temp2(std::cos(dphi_norm / 2), dphi_dir[0], dphi_dir[1], dphi_dir[2]);
//    curr_state.q = curr_state.q * temp2;
//    curr_state.q.normalize();

    // 更新acc_bias,gyro_bias
    curr_state.acc_bias += errors.segment(9,3);
    curr_state.gyro_bias+= errors.segment(12,3);

    // 更新重力
//    curr_state.g += errors.segment(15,3);

    curr_state.q_i_l = curr_state.q_i_l * Eigen::Quaterniond(
                                              theta2q(errors.segment(15,3)));

    curr_state.t_i_l += errors.segment(18,3);

    curr_state.timestamp=measure.timestamp;

//    log_State_nominal(curr_state);
//    log_Matrix("P:", P);

    //重置误差状态为零，更新误差状态协方差P
//    Eigen::MatrixXd G = Eigen::MatrixXd::Identity(err_state.Vec.size(), err_state.Vec.size());
//    G.block<3,3>(3, 3)= M3d::Identity() - skew_matrix(0.5 * errors.segment(3, 3));
//    this->P = G * this->P * G.transpose();
}

const StateNominal ESKF::getCurrState() {
    StateNominal data=curr_state;
    return data;
}




