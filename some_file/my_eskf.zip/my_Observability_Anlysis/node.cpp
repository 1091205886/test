/* Copyright (c) 2023 Unity-Drive Inc. All rights reserved */
/*
 * @file       node.cpp
 * @author     Qian Peicong
 * @brief
 * @date       2023-05-12
 * @version    1.0.0
 */

#include <memory>

#include <ros/ros.h>
#include <sensor_msgs/Imu.h>
#include <nav_msgs/Odometry.h>
#include <iostream>
#include <deque>
#include "utils.h"
#include "ESKF.h"
#include <yaml.h>

ESKF::Ptr eskf_ptr;
bool inited = false;
ImuMsg last_imu_msg;
std::deque<ImuMsg,Eigen::aligned_allocator<ImuMsg>> imu_msgs;
std::shared_ptr<MeasurementNoise> mea_noise_ptr;
ros::Publisher filtered_pose_pub;

void ImuCallback(const sensor_msgs::ImuConstPtr& imu_msg_ptr)
{

    ImuMsg imu_data;
    imu_data.timestamp = imu_msg_ptr->header.stamp.toSec();
    imu_data.acc_m << imu_msg_ptr->linear_acceleration.x,
            imu_msg_ptr->linear_acceleration.y,
            imu_msg_ptr->linear_acceleration.z;
    imu_data.gyro_m << imu_msg_ptr->angular_velocity.x,
            imu_msg_ptr->angular_velocity.y,
            imu_msg_ptr->angular_velocity.z;

    imu_msgs.push_back(imu_data);

    if(last_imu_msg.timestamp == 0)
    {
        last_imu_msg = imu_data;
        return;
    }

    //    imu_data_ptr->gyro = imu_data_ptr->gyro * M_PI / 180;
    //
    //    imu_data_ptr->acc = imu_data_ptr->acc * 9.806;


//  //ROS_WARN("ImuProcessor::Predict delta_t [%f]", imu_data_ptr->timestamp - last_imu_time);
//  last_imu_time = ros::Time::now().toSec(); //imu_msg_ptr->header.stamp.toSec();
//  last_imu_data_ = imu_msg_ptr;
//
//  imu_data_cache_.emplace_back(imu_data_ptr);

//  if(filter2_ptr_){
//    State fused_state;
//    bool ok = filter2_ptr_->ProcessImuData(imu_data_ptr, &fused_state);
//    auto dia_cov = filter2_ptr_->state_.cov.diagonal();
//    std_msgs::Float64MultiArray cov_array;
//    for(int i=0; i < dia_cov.size(); ++i){
//      cov_array.data.push_back(dia_cov(i));
//    }
//    pubErrStateCov.publish(cov_array);
//    ConvertStateToRosTopic(fused_state, imu_data_ptr->timestamp);
//  }
}

void LocCallback(const nav_msgs::OdometryConstPtr & pose_msg)
{
    StateNominal pose_mea;
    pose_mea.timestamp = pose_msg->header.stamp.toSec();
    pose_mea.p.x() = pose_msg->pose.pose.position.x;
    pose_mea.p.y() = pose_msg->pose.pose.position.y;
    pose_mea.p.z() = pose_msg->pose.pose.position.z;

    pose_mea.q.w() = pose_msg->pose.pose.orientation.w;
    pose_mea.q.x() = pose_msg->pose.pose.orientation.x;
    pose_mea.q.y() = pose_msg->pose.pose.orientation.y;
    pose_mea.q.z() = pose_msg->pose.pose.orientation.z;

    if(!inited){
        /// 1. init
        eskf_ptr->init_state_nominal(pose_mea);
        eskf_ptr->log_state_nominal();
        inited = true;
    }

    while (!imu_msgs.empty() && imu_msgs.front().timestamp < pose_mea.timestamp)
    {
        const auto& imu_msg = imu_msgs.front();
        if(!eskf_ptr->predict(imu_msg)){
            eskf_ptr->predict_pose_.emplace_back(eskf_ptr->getCurrState());
            continue;
        }
        imu_msgs.pop_front();
    }

//    Eigen::Vector3d pos_noise=Eigen::Vector3d::Random()*mea_noise.p_noise_sigma;
//            measure.p += pos_noise;
    //更新
    eskf_ptr->update(pose_mea,*mea_noise_ptr);

    nav_msgs::Odometry pose_pub;
    pose_pub.header = pose_msg->header;
    pose_pub.pose.pose.position.x = eskf_ptr->getCurrState().p.x();
    pose_pub.pose.pose.position.y = eskf_ptr->getCurrState().p.y();
    pose_pub.pose.pose.position.z = eskf_ptr->getCurrState().p.z();
    pose_pub.pose.pose.orientation.w = eskf_ptr->getCurrState().q.w();
    pose_pub.pose.pose.orientation.x = eskf_ptr->getCurrState().q.x();
    pose_pub.pose.pose.orientation.y = eskf_ptr->getCurrState().q.y();
    pose_pub.pose.pose.orientation.z = eskf_ptr->getCurrState().q.z();
    pose_pub.pose.covariance.data()[0] = eskf_ptr->P(0,0);
    pose_pub.pose.covariance.data()[7] = eskf_ptr->P(1,1);
    pose_pub.pose.covariance.data()[14] = eskf_ptr->P(2,2);
    pose_pub.pose.covariance.data()[21] = eskf_ptr->P(6,6);
    pose_pub.pose.covariance.data()[28] = eskf_ptr->P(7,7);
    pose_pub.pose.covariance.data()[35] = eskf_ptr->P(8,8);
    filtered_pose_pub.publish(pose_pub);

    static int cnt=0;
    if(cnt++ % 100 == 0){
        std::cout<<"===============State===================="<<std::endl;
        log_State_nominal(eskf_ptr->getCurrState());
    }
}

int main (int argc, char** argv) {
    // Set glog.
//  FLAGS_colorlogtostderr = true;
//
//  ros::console::set_logger_level(ROSCONSOLE_DEFAULT_NAME, ros::console::levels::Debug);
//
    // Initialize ros.
    ros::init(argc, argv, "my_eskf");
    ros::NodeHandle nh;

    YAML::Node config_node = YAML::LoadFile("/home/udi/shared_dir/eskf_ws/src/my_Observability_Anlysis/param/ins.yaml");
    ImuParam imu_param(config_node["ImuParam"]);
    mea_noise_ptr = std::make_shared<MeasurementNoise>(config_node["MeasurementNoise"]);

    eskf_ptr=eskf_ptr->create(imu_param);

//    int cnt=0,cntt=0;
//    int state_size = eskf_ptr->Ft.cols();
//    int mea_size = eskf_ptr->Gt.rows();

    ros::Subscriber imu_sub = nh.subscribe("/sys_data_hub/imu_data", 100, &ImuCallback);
    ros::Subscriber pose_sub = nh.subscribe("/current_odom_lidar", 100, &LocCallback);
    filtered_pose_pub = nh.advertise<nav_msgs::Odometry>("/current_odom_filtered", 100);

    ros::spin();
    return 1;
}