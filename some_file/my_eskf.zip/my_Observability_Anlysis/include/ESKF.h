//
// Created by msi on 2020/7/16.
//

#ifndef ESKF_CPP_ESKF_H
#define ESKF_CPP_ESKF_H

#include "utils.h"
#include <vector>
#include <memory>
#include <string>
#include <fstream>
//#include <sophus/se3.hpp>

typedef Eigen::Vector3d V3d;
typedef Eigen::Matrix3d M3d;

class ESKF {

public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW

    typedef std::unique_ptr<ESKF> Ptr;

    inline static Ptr create(ImuParam param) {
        return std::unique_ptr<ESKF>(new ESKF(param));
    }

protected:
    ESKF(const ImuParam& param) : imu_param(param)
    {
        // 取状态维度
        int vec_size=err_state.Vec.size();
        // 矩阵初始化
        Fi=Eigen::MatrixXd::Zero(vec_size, 12);
        Fi.block<3,3>(3, 0)=M3d::Identity();
        Fi.block<3,3>(6, 3)=M3d::Identity();
        Fi.block<3,3>(9, 6)=M3d::Identity();
        Fi.block<3,3>(12, 9)=M3d::Identity();

        Eigen::Matrix<double, 12, 12> tmp_Q_init=Eigen::Matrix<double, 12, 12>::Zero();
        tmp_Q_init.block<3,3>(0,0)=pow(param.acc_noise_sigma,2)*Eigen::Matrix3d::Identity();
        tmp_Q_init.block<3,3>(3,3)=pow(param.gyro_noise_sigma,2)*Eigen::Matrix3d::Identity();
        tmp_Q_init.block<3,3>(6,6)=pow(param.acc_bias_sigma,2)*Eigen::Matrix3d::Identity();
        tmp_Q_init.block<3,3>(9,9)=pow(param.gyro_bias_sigma,2)*Eigen::Matrix3d::Identity();

        Qi = tmp_Q_init;

        P=Eigen::MatrixXd::Zero(vec_size,vec_size);
        P.setIdentity();
        P.block<3,3>(0,0) = M3d::Identity() * 1e-4;
        P.block<3,3>(3,3) = M3d::Identity() * 1e-4;
        P.block<3,3>(6,6) = M3d::Identity() * 1e-4;
        P.block<3,3>(9,9) = M3d::Identity() * 1e-5;
        P.block<3,3>(12,12) = M3d::Identity() * 1e-5;
        P.block<3,3>(15,15) = M3d::Identity() * 1e-4;
        P.block<3,3>(18,18) = M3d::Identity() * 1e-4;
        log_Matrix("P:", P);

        Ft=Eigen::MatrixXd::Zero(vec_size,vec_size);
        Gt=Eigen::MatrixXd::Zero(3,vec_size);
//        Gt.block<3,3>(0,0)=Eigen::Matrix3d::Identity();
        Yt=Eigen::MatrixXd::Zero(3,1);
//        Ot=Eigen::MatrixXd::Zero(3*vec_size,vec_size);
//        // 下面这两个在后期会扩充
//        Oso=Eigen::MatrixXd::Zero(3*vec_size,vec_size);
//        Y=Eigen::MatrixXd::Zero(3*vec_size,1);
    }

    // 禁用复制构造函数
    ESKF(const ESKF &) = delete;

    ESKF &operator=(const ESKF &) = delete;
public:
    void init_state_nominal(const StateNominal &input);
    void update_imu_msg(const ImuMsg &curr_m);

    void log_state_nominal();

    bool predict(const ImuMsg &imu_msg_);
    void _predict_err_covar(const ImuMsg &imu_msg_);
    void _predict_nominal_state(const ImuMsg &imu_msg_);

    void update(const StateNominal & measure, const MeasurementNoise &noise);

    void init_observability_anlysis();
    void update_observability_anlysis(const StateNominal & measure,int index);
    void solve_observability_anlysis(bool reset);

    const StateNominal getCurrState();
private:
    int id;
    StateNominal curr_state;
    StateError err_state;
    ImuMsg curr_imu;
    double timestamp=0;
    const ImuParam imu_param;
public:
    Eigen::MatrixXd Qi;          // 噪声协方差矩阵(用于初始化的)
    Eigen::MatrixXd Fi;
    Eigen::MatrixXd P;
    Eigen::MatrixXd Ft;
    Eigen::MatrixXd Gt;
    Eigen::MatrixXd Ot;
    Eigen::MatrixXd Yt;
    Eigen::MatrixXd Oso;
    Eigen::MatrixXd Y;
    double delta_t = 0;

    std::deque<StateNominal,Eigen::aligned_allocator<StateNominal>> predict_pose_;
    std::deque<StateNominal,Eigen::aligned_allocator<StateNominal>> update_pose_;

//    double deltaT=0.005;
    double latitude=32;
    double longitude=120;
    double altitude=0;
    double wie=7.2921151467e-5;
    double f=1/298.257223563;
    double e=sqrt(2*f-f*f);
    double Re=6.378136460e+6;
    double Rn=Re/sqrt(1-e*e*sin(latitude)*sin(latitude));
    double Rm=Rn*(1-e*e)/(1-e*e*sin(latitude)*sin(latitude));
    Eigen::Vector3d gravity=Eigen::Vector3d(0,0,-9.8);
};


#endif //ESKF_CPP_ESKF_H
