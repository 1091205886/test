//
// Created by msi on 2020/7/16.
//
#pragma once
#ifndef ESKF_CPP_UTILS_H
#define ESKF_CPP_UTILS_H

#include <iostream>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>
//#include <sophus/so3.hpp>
//#include <sophus/se3.hpp>
#include <vector>
#include <memory>
#include <string>
#include <fstream>
#include <deque>
#include <iomanip>
#include "tic_toc.hpp"
#include <yaml-cpp/yaml.h>
class utils {

};

struct ImuMsg {
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW
    double timestamp=0;
    Eigen::Vector3d acc_m=Eigen::Vector3d::Zero();
    Eigen::Vector3d gyro_m=Eigen::Vector3d::Zero();
    Eigen::Vector3d gps_=Eigen::Vector3d(0,0,0);

    ImuMsg(){
    }
    void Log(){
        std::cout<<std::setprecision(12);
        std::cout<<"Time: "<<timestamp<<"====================================================="
                 <<std::endl;
        std::cout<<"Acc:"<<acc_m.transpose()<<std::endl;
        std::cout<<"Gyro:"<<gyro_m.transpose()<<std::endl;
        std::cout<<"GPS:"<<gps_.transpose()<<std::endl;
    }
};

struct ImuParam
{
    double acc_noise_sigma;
    double gyro_noise_sigma;
    double acc_bias_sigma;
    double gyro_bias_sigma;
    ImuParam()
    {
        acc_noise_sigma=1e-4;  // m/sqrt(s^3) (continuous noise)
        gyro_noise_sigma=1e-5; // rad/sqrt(s) (continuous noise)
        acc_bias_sigma=1e-4; // m/sqrt(s^5)     (continuous bias)
        gyro_bias_sigma=2.0e-5; // rad/sqrt(s^3)   (continuous bias)
    }
    ImuParam(const YAML::Node& node)
    {
        if(!node.IsDefined()){
          std::cout<<__PRETTY_FUNCTION__<<" failed for YAML::Node is not defined."<< std::endl;
        }

        try{
          acc_noise_sigma = node["acc_noise_sigma"].as<double>();
        }catch (const std::exception& e){
          acc_noise_sigma=1e-4;
          std::cout<<__PRETTY_FUNCTION__<<" [acc_noise_sigma] is not set. Using default value: "<< acc_noise_sigma << std::endl;
        }

        try{
          gyro_noise_sigma = node["gyro_noise_sigma"].as<double>();
        }catch (const std::exception& e){
          gyro_noise_sigma=1e-5;
          std::cout<<__PRETTY_FUNCTION__<<" [gyro_noise_sigma] is not set. Using default value: "<< gyro_noise_sigma << std::endl;
        }

        try{
          acc_bias_sigma = node["acc_bias_sigma"].as<double>();
        }catch (const std::exception& e){
          acc_bias_sigma=1e-4;
          std::cout<<__PRETTY_FUNCTION__<<" [acc_bias_sigma] is not set. Using default value: "<< acc_bias_sigma << std::endl;
        }

        try{
          gyro_bias_sigma = node["gyro_bias_sigma"].as<double>();
        }catch (const std::exception& e){
          gyro_bias_sigma=2.0e-5;
          std::cout<<__PRETTY_FUNCTION__<<" [gyro_bias_sigma] is not set. Using default value: "<< gyro_bias_sigma << std::endl;
        }
    }

};

struct StateNominal {
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW
    Eigen::Vector3d p=Eigen::Vector3d::Zero();
    Eigen::Vector3d v=Eigen::Vector3d::Zero();
    Eigen::Quaterniond q=Eigen::Quaterniond::Identity();
    Eigen::Vector3d euler=Eigen::Vector3d::Zero();
    Eigen::Vector3d v_b=Eigen::Vector3d::Zero();
    Eigen::Vector3d acc_bias=Eigen::Vector3d::Zero();
    Eigen::Vector3d gyro_bias=Eigen::Vector3d::Zero();
    Eigen::Quaterniond q_i_l = Eigen::Quaterniond::Identity();
    Eigen::Vector3d t_i_l = Eigen::Vector3d::Zero();
    Eigen::Vector3d g=Eigen::Vector3d::Zero();
    double timestamp=0;
    StateNominal(){

    }
    void Log(){
        std::cout<<std::setprecision(18);
        std::cout<<"Time: "<<timestamp<<"====================================================="
                 <<std::endl;
        std::cout<<"Position:"<<p.transpose()<<std::endl;
        std::cout<<"Velocity_b:"<<v_b.transpose()<<std::endl;
        std::cout<<"Velocity:"<<v.transpose()<<std::endl;
        std::cout<<"Attitude:"<<q.coeffs().transpose()<<std::endl;
        std::cout<<"Euler:"<<euler.transpose()<<std::endl;
    }
};

struct StateError {
    Eigen::Matrix<double,21,1> Vec;
    Eigen::Ref<Eigen::Vector3d> p_delta=Vec.block(0, 0, 3, 1);
    Eigen::Ref<Eigen::Vector3d> v_delta=Vec.block(3, 0, 3, 1);
    Eigen::Ref<Eigen::Vector3d> xita_delta=Vec.block(6, 0, 3, 1);
    Eigen::Ref<Eigen::Vector3d> acc_bias_delta=Vec.block(9, 0, 3, 1);
    Eigen::Ref<Eigen::Vector3d> gyro_bias_delta=Vec.block(12, 0, 3, 1);
    Eigen::Ref<Eigen::Vector3d> q_i_l_delta = Vec.block(15, 0, 3, 1);
    Eigen::Ref<Eigen::Vector3d> t_i_l_delta = Vec.block(18, 0, 3, 1);
    StateError(){
        Vec.setZero();
    }
};

struct MeasurementNoise {
    double p_noise_sigma=1e-6;      // in meters    观测噪声，标准差
    double q_noise_sigma=1e-6;     // in rad
    double v_noise_sigma=1e-6;
    MeasurementNoise(const YAML::Node& node){
        if(!node.IsDefined()){
          std::cout<<__PRETTY_FUNCTION__<<" failed for YAML::Node is not defined."<< std::endl;
        }

        try{
          p_noise_sigma = node["p_noise_sigma"].as<double>();
        }catch (const std::exception& e){
          p_noise_sigma=1e-6;
          std::cout<<__PRETTY_FUNCTION__<<" [p_noise_sigma] is not set. Using default value: "<< p_noise_sigma << std::endl;
        }

        try{
          q_noise_sigma = node["q_noise_sigma"].as<double>();
        }catch (const std::exception& e){
          q_noise_sigma=1e-6;
          std::cout<<__PRETTY_FUNCTION__<<" [q_noise_sigma] is not set. Using default value: "<< q_noise_sigma << std::endl;
        }

        try{
          v_noise_sigma = node["v_noise_sigma"].as<double>();
        }catch (const std::exception& e){
          v_noise_sigma=1e-6;
          std::cout<<__PRETTY_FUNCTION__<<" [v_noise_sigma] is not set. Using default value: "<< v_noise_sigma << std::endl;
        }
    }
};

void log_State_nominal(StateNominal input);

void log_Matrix(std::string str,Eigen::MatrixXd mat);

Eigen::Quaterniond theta2q(const Eigen::Vector3d theta);
Eigen::Quaterniond theta2q(const Eigen::Vector3d gyro, double delta_t);

Eigen::Matrix3d q2RotMat(const Eigen::Quaterniond& q);

void normalizeQ(Eigen::Quaterniond &q);

Eigen::Matrix3d skew_matrix(Eigen::Vector3d);

void readIMUData(const std::string &acc,const std::string &gyro,const std::string &time,std::deque<ImuMsg,Eigen::aligned_allocator<ImuMsg>>& imu_msg);
void readGTData(const std::string &pos, const std::string &atti, const std::string& velocity, const std::string &time,std::deque<StateNominal,Eigen::aligned_allocator<StateNominal>>& imu_msg);
void LoadData(std::string filename, std::deque<ImuMsg,Eigen::aligned_allocator<ImuMsg>>& imu_msg);
void LoadData(std::string filename, std::deque<StateNominal,Eigen::aligned_allocator<StateNominal>>& pose);
void SaveData(std::string outputFile,const std::deque<StateNominal,Eigen::aligned_allocator<StateNominal>> pose);
void SaveState(std::string outputFile, std::deque<StateNominal,Eigen::aligned_allocator<StateNominal>> poses);
void SaveImuData(std::string outputFile,const std::deque<ImuMsg,Eigen::aligned_allocator<ImuMsg>>& imu_msg);

#endif //ESKF_CPP_UTILS_H
